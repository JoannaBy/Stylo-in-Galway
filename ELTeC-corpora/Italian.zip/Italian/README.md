ELTeC corpus retrieved from https://github.com/COST-ELTeC/ELTeC-ita/
level 1 folder, as of commit from Nov 24, 2018
