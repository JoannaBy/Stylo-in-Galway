ELTeC corpus retrieved from https://github.com/COST-ELTeC/ELTeC-slv
level 1 folder, as of commit from Oct 28, 2018
