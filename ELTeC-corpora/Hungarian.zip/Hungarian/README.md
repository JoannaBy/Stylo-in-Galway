Corpus retrieved from https://github.com/COST-ELTeC/ELTeC-hun lvl0 - status as of  Nov 22, 2018.
Altered file names to facilitate author oriented analysis.
