ELTeC corpus retrieved from https://github.com/COST-ELTeC/ELTeC-fra
level 1 folder, as of commit from Nov 28, 2018
